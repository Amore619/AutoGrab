package com.example.autoclicker;

import android.app.admin.DeviceAdminReceiver;

/**
 * 仅用于「静默巡逻结束后自动关屏」。
 * 不涉及任何其他设备管理能力（不擦除、不改密码、不锁屏策略）。
 */
public class SleepAdmin extends DeviceAdminReceiver {
}
