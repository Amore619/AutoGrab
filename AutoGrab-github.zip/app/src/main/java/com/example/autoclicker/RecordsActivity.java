package com.example.autoclicker;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class RecordsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ListView lv = new ListView(this);
        ArrayList<String> items = new ArrayList<>();
        File f = new File(getFilesDir(), GrabService.RECORD_FILE);
        if (f.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = r.readLine()) != null) {
                    items.add(line);
                }
            } catch (Exception ignored) {
            }
        }
        if (items.isEmpty()) {
            items.add("暂无记录。命中活动后会自动记录在这里。");
        }
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        lv.setAdapter(ad);
        setContentView(lv);
    }
}
