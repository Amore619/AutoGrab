package com.example.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Path;
import android.graphics.Rect;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * 目标APP（com.example.targetapp）入口B活动全自动目标按钮服务。
 *
 * 真实页面流程（依据实机截图）：
 *   1) APP 首页「热门专题」区块下的蓝色卡片 —— 文本「入口A」
 *   2) 入口A页（H5）九宫格第一个 —— 文本「入口B」
 *   3) 入口B页顶部四个模块 —— 文本「入口C」（图标+文字）
 *   4) 入口C列表页 —— 每张活动卡片右下角按钮为「详情」/「目标按钮」
 *      · 状态为「进行中」「已结束」的卡片只有「详情」，绝不能点
 *      · 只有可目标按钮的卡片才出现「目标按钮」按钮
 *   5) 点「目标按钮」后可能出现确认弹窗（确定/确认/提交/立即目标按钮/我已知晓）
 *
 * 安全策略：点击前先判定节点文本，含"详情"直接跳过；只点精确等于"目标按钮"的按钮。
 */
public class GrabService extends AccessibilityService {

    public static final String ACTION_STOP = "com.example.autoclicker.STOP";
    public static final String ACTION_PATROL = "com.example.autoclicker.PATROL";
    public static final String ACTION_PATROL_STOP = "com.example.autoclicker.PATROL_STOP";
    public static final String EXTRA_INTERVAL_MIN = "interval_min";
    public static final String EXTRA_BATTERY_MIN = "battery_min";
    public static final String ACTION_DIAG = "com.example.autoclicker.DIAG";
    public static final String ACTION_DUMP = "com.example.autoclicker.DUMP";
    public static final String ACTION_SCROLL_DIAG = "com.example.autoclicker.SCROLL_DIAG";
    public static final String ACTION_AWAY = "com.example.autoclicker.AWAY";
    public static final String ACTION_BACK = "com.example.autoclicker.BACK";
    public static final String EXTRA_BRIGHTNESS = "brightness";
    public static final String RECORD_FILE = "grab_records.txt";

    private static final String TARGET_PKG = "com.example.targetapp";
    private static final long TICK = 800;
    private static final long NAV_TIMEOUT = 60_000;      // 导航阶段容错超时
    private static final long HUNT_IDLE_TIMEOUT = 3_600_000; // 最长蹲守 60 分钟
    private static final long AUTO_REFRESH_MS = 10_000;  // 未出现"目标按钮"时的刷新间隔
    private static final long SCROLL_MS = 18_000;        // 列表页无目标按钮时的自动下滑间隔

    /** 手势安全边距：避开状态栏、导航栏、左右返回手势区，防止误触和画面抖动 */
    private static final float SAFE_TOP_RATIO = 0.16f;
    private static final float SAFE_BOTTOM_RATIO = 0.90f;

    private enum Step {
        IDLE, WAIT_TARGET, FIND_DACHUAN, DELAY,
        FIND_XINYU, FIND_ACTIVITY_TAB,
        HUNT, CONFIRM, DONE
    }

    private Step step = Step.IDLE;
    private Step pendingStep = null;   // DELAY 结束后要进入的状态
    private long delayUntil = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private long stepStart = 0;
    private long lastRefresh = 0;
    private long huntStart = 0;
    private int faultCount = 0;
    private int confirmTries = 0;
    private String grabbedName = "入口B活动";
    private String lastLog = "";

    // ---- 静默巡逻（仅在息屏时工作）----
    private int batteryMin = 20;      // 电量低于此值自动停止（可调）
    private boolean awayMode = false;
    private int awayBrightness = 115; // 45% of 255
    private int lastSysBrightness = -1;
    private int cycleCount = 0;
    private long lastCheckAt = 0;
    private long lastNotifyAt = 0;
    private long lastBatteryCheck = 0;
    private String lastGestureResult = "";
    private boolean dachuanTried = false;
    private int scrollAttempts = 0;
    private long lastScrollTry = 0;
    private boolean patrolActive = false;


    private long lastScrollAt = 0;
    private boolean scrollBackPending = false;

    private final Runnable tick = this::tickOnce;

    // ======================= 生命周期 =======================

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        createChannel();
        logStatus("无障碍服务已连接，等待启动");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            if (awayMode) exitAwayMode("已停止离开模式");
            stopNow("收到手动停止指令");
            return START_NOT_STICKY;
        }
        if (ACTION_PATROL_STOP.equals(action)) {
            if (awayMode) exitAwayMode("已关闭");
            patrolActive = false;
            logStatus("已全部停止");
            return START_STICKY;
        }
        if (ACTION_SCROLL_DIAG.equals(action)) {
            handler.postDelayed(this::diagScroll, 8000);
            return START_STICKY;
        }
        if (ACTION_DUMP.equals(action)) {
            dumpScreen();
            return START_STICKY;
        }
        if (ACTION_DIAG.equals(action)) {
            sendDiag("状态=" + step.name()
                    + (awayMode ? " | 离开模式运行中" : " | 空闲")
                    + " | 电量 " + batteryLevel() + "%");
            return START_STICKY;
        }
        if (ACTION_AWAY.equals(action)) {
            if (intent != null) {
                batteryMin = intent.getIntExtra(EXTRA_BATTERY_MIN, batteryMin);
                awayBrightness = intent.getIntExtra(EXTRA_BRIGHTNESS, awayBrightness);
            }
            enterAwayMode();
            return START_STICKY;
        }
        if (ACTION_BACK.equals(action)) {
            exitAwayMode("你回来了，已恢复亮度");
            return START_STICKY;
        }
        if (ACTION_PATROL.equals(action)) {
            if (intent != null) batteryMin = intent.getIntExtra(EXTRA_BATTERY_MIN, batteryMin);
            patrolActive = true;
            enterAwayMode();
            logStatus("巡逻已开启（电量低于 " + batteryMin + "% 自动停）");
            return START_STICKY;
        }
        // 手动单次启动
        if (step == Step.IDLE || step == Step.DONE) {
            startFlow();
        }
        return START_STICKY;
    }

    /** 启动一轮完整流程 */
    private void startFlow() {
        step = Step.WAIT_TARGET;
        stepStart = now();
        faultCount = 0;
        confirmTries = 0;
        handler.removeCallbacks(tick);
        handler.postDelayed(tick, 300);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override
    public boolean onUnbind(Intent intent) {
        handler.removeCallbacks(tick);

        handler.removeCallbacks(startHuntRunnable);
        patrolActive = false;
        awayMode = false;
        restoreBrightness();
        cancelStatusNotification();
        step = Step.IDLE;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);

        handler.removeCallbacks(startHuntRunnable);
        restoreBrightness();
        cancelStatusNotification();
        super.onDestroy();
    }

    // ======================= 静默巡逻（仅息屏工作）=======================

    // ---------- 离开模式 ----------

    /** 进入离开模式：调暗屏幕 → 5 秒后跳到目标APP → 开始盯列表 */
    private void enterAwayMode() {
        awayMode = true;
        cycleCount = 0;
        lastCheckAt = 0;
        dachuanTried = false;
        scrollAttempts = 0;
        lastScrollTry = 0;

        boolean dimOk = Settings.System.canWrite(this);
        if (dimOk) {
            dimScreen(awayBrightness);
            logStatus("屏幕亮度已调暗，5 秒后切换到目标APP");
        } else {
            logStatus("⚠ 未获得「修改系统设置」权限，无法调暗屏幕（请在首页重新点「我离开了」并授权）");
        }
        updateStatusNotification(dimOk ? "已进入离开模式，5 秒后开始" : "离开模式已开（亮度权限未授予）");
        handler.removeCallbacks(startHuntRunnable);
        handler.postDelayed(startHuntRunnable, 5000);
    }

    private final Runnable startHuntRunnable = () -> {
        if (!awayMode) return;
        launchTarget();
        handler.postDelayed(() -> {
            if (!awayMode) return;
            startFlow();
            logStatus("已打开目标APP，开始盯屏");
        }, 2500);
    };

    /** 退出离开模式：恢复亮度、停止流程 */
    private void exitAwayMode(String why) {
        awayMode = false;
        handler.removeCallbacks(startHuntRunnable);
        handler.removeCallbacks(tick);
        step = Step.IDLE;
        restoreBrightness();
        cancelStatusNotification();
        logStatus(why);
        sendBroadcast(new Intent("com.example.autoclicker.AWAY_STATE").setPackage(getPackageName())
                .putExtra("away", false));
    }

    /** 屏幕亮度：0~255，-1 表示恢复系统自动 */
    private void dimScreen(int value) {
        if (!Settings.System.canWrite(this)) {
            sendBroadcast(new Intent("com.example.autoclicker.NEED_WRITE_SETTINGS").setPackage(getPackageName()));
            return;
        }
        try {
            if (lastSysBrightness < 0) {
                lastSysBrightness = Settings.System.getInt(getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS, 128);
            }
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, value);
        } catch (Exception e) {
            logStatus("调亮度失败：" + e.getMessage());
        }
    }

    private void restoreBrightness() {
        if (lastSysBrightness < 0) return;
        try {
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, lastSysBrightness);
            lastSysBrightness = -1;
        } catch (Exception ignored) {
        }
    }

    // ---------- 状态通知（让你随时确认它活着）----------

    private void updateStatusNotification(String text) {
        try {
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                b = new Notification.Builder(this, "grab_status_v2");
            } else {
                b = new Notification.Builder(this);
            }
            String time = new SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(new Date());
            b.setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("自动目标按钮助手 · 运行中")
                    .setContentText(text + " ｜最近检查 " + time)
                    .setStyle(new Notification.BigTextStyle()
                            .bigText(text + "\n累计检查 " + cycleCount + " 次\n最近一次：" + time
                                    + "\n\n如果这条通知的时间不再更新，说明服务被系统杀掉了。"))
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setPriority(Notification.PRIORITY_LOW)
                    .setContentIntent(android.app.PendingIntent.getActivity(
                            this, 0,
                            new Intent(this, MainActivity.class)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                            android.app.PendingIntent.FLAG_IMMUTABLE
                                    | android.app.PendingIntent.FLAG_UPDATE_CURRENT))
                    .setVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(3001, b.build());
        } catch (Exception ignored) {
        }
    }

    private void cancelStatusNotification() {
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.cancel(3001);
        } catch (Exception ignored) {
        }
    }


    /** 当前电量百分比，取不到返回 -1 */
    private int batteryLevel() {
        try {
            Intent b = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b == null) return -1;
            int level = b.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
            int scale = b.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
            if (level < 0 || scale <= 0) return -1;
            return level * 100 / scale;
        } catch (Exception e) {
            return -1;
        }
    }

    /** 把运行状态广播给界面，便于排查 */
    private void sendDiag(String msg) {
        try {
            sendBroadcast(new Intent("com.example.autoclicker.DIAG").setPackage(getPackageName())
                    .putExtra("msg", msg));
        } catch (Exception ignored) {
        }
    }

    /** 关屏（需要设备管理器权限；没有权限则退化为保持不亮屏） */
    private void goToSleep() {
        try {
            android.app.admin.DevicePolicyManager dpm =
                    (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            if (dpm != null && dpm.isAdminActive(new android.content.ComponentName(this, SleepAdmin.class))) {
                dpm.lockNow();
            }
        } catch (Exception ignored) {
        }
    }

    // ======================= 状态机 =======================

    private void tickOnce() {
        if (step == Step.IDLE || step == Step.DONE) return;
        long now = now();

        // 关键延迟：等待 3~5 秒后再进入下一阶段
        if (step == Step.DELAY) {
            if (now >= delayUntil && pendingStep != null) {
                Step next = pendingStep;
                pendingStep = null;
                if (next == Step.HUNT) startHunt();
                else setStep(next);
            }
            handler.postDelayed(tick, 200);
            return;
        }

        long elapsed = now - stepStart;

        try {
            switch (step) {
                case WAIT_TARGET:
                    if (isTargetForeground()) {
                        if (pageReady()) {
                            // 先判断当前在哪一页，从那一页接着走，而不是无脑从头开始
                            Step from = detectCurrentPage();
                            if (from == Step.HUNT) {
                                logStatus("检测到已在活动列表页，直接开始盯【目标按钮】");
                                startHunt();
                            } else if (from == Step.FIND_XINYU) {
                                logStatus("检测到在入口B页，寻找【入口C】");
                                setStep(Step.FIND_XINYU);
                            } else if (from == Step.FIND_ACTIVITY_TAB) {
                                logStatus("检测到在入口B页，寻找【入口C】入口");
                                setStep(Step.FIND_ACTIVITY_TAB);
                            } else {
                                logStatus("检测到目标APP首页，开始寻找【入口A】");
                                setStep(Step.FIND_DACHUAN);
                            }
                        }
                    } else if (elapsed > 8_000) {
                        launchTarget();
                        stepStart = now();
                    }
                    break;

                case FIND_DACHUAN:
                    if (elapsed > NAV_TIMEOUT) { faultTolerance("首页未找到【入口A】"); break; }
                    // 滚动阶段：1.5秒一轮，共12轮；滚动指令和手势轮流上（不确定哪条有效，两条都用）
                    if (elapsed < 20_000 && scrollAttempts < 12) {
                        if (now - lastScrollTry > 1500) {
                            lastScrollTry = now();
                            scrollAttempts++;
                            if (scrollAttempts % 2 == 1) {
                                scrollForwardByAction();
                                logStatus("滚动 " + scrollAttempts + "/12（滚动指令）");
                            } else {
                                swipeUpHalf();
                                logStatus("滚动 " + scrollAttempts + "/12（手势滑动）");
                            }
                        }
                        break;
                    }
                    // 滚动阶段结束（或页面已变化），开始点入口A
                    if (clickByText("入口A", false) || clickDachuanByCoord()) {
                        logStatus("已点击【入口A】，等待网页加载 3~5 秒");
                        beginDelay(Step.FIND_XINYU);
                    }
                    break;

                case FIND_XINYU:
                    if (elapsed > NAV_TIMEOUT) { faultTolerance("未找到【入口B】"); break; }
                    if (clickByText("入口B", false) || clickXinyuByCoord()) {
                        logStatus("已点击【入口B】，等待页面加载 3~5 秒");
                        beginDelay(Step.FIND_ACTIVITY_TAB);
                    }
                    break;

                case FIND_ACTIVITY_TAB:
                    // 入口B首页顶部有"入口C"模块；若已经直接进入列表则跳过
                    if (clickByText("入口C", false)
                            || (elapsed > 5000 && clickActivityTabByCoord())) {
                        logStatus("已进入【入口C】列表，等待加载 3~5 秒");
                        beginDelay(Step.HUNT);
                    } else if (findExact("目标按钮")) {
                        logStatus("已在活动列表页");
                        startHunt();
                    } else if (elapsed > NAV_TIMEOUT) {
                        faultTolerance("未找到【入口C】入口");
                    }
                    break;

                case HUNT:
                    // 电量保护（每 30 秒查一次即可，避免频繁读广播）
                    if (now - lastBatteryCheck > 30000) {
                        lastBatteryCheck = now;
                        int bl = batteryLevel();
                        if (bl >= 0 && bl < batteryMin) {
                            logStatus("电量低于 " + batteryMin + "%，已停止");
                            if (awayMode) exitAwayMode("电量过低自动停止");
                            else stopNow("电量过低自动停止");
                            break;
                        }
                    }
                    // 心跳：更新通知，让你知道它还活着
                    if (now - lastCheckAt > 15000) {
                        lastCheckAt = now;
                        cycleCount++;
                        updateStatusNotification("正在盯活动列表");
                    }
                    // 只点精确等于"目标按钮"的按钮，含"详情"的节点被排除
                    if (clickExactBaoming()) {
                        logStatus("★ 发现【目标按钮】按钮，立即点击！");
                        confirmTries = 0;
                        setStep(Step.CONFIRM);
                    } else if (now - lastRefresh >= AUTO_REFRESH_MS) {
                        logStatus("未发现【目标按钮】，执行下拉刷新");
                        swipeRefresh();
                        lastRefresh = now();
                        lastScrollAt = now();
                    } else if (now - lastRefresh >= 6000 && now - lastScrollAt >= SCROLL_MS) {
                        // 列表较长：滑一次看下面的卡片；滑完给页面留出稳定时间，避免来回连抖
                        swipeUpHalf();
                        lastScrollAt = now();
                        lastRefresh = now(); // 重新计时，保证不会立刻又下拉
                    }
                    break;

                case CONFIRM:
                    confirmTries++;
                    if (clickAnyExact(new String[]{"确定", "确认", "提交", "立即目标按钮", "我已知晓", "同意"})) {
                        logStatus("已点击确认弹窗");
                        handler.postDelayed(this::success, 1200);
                    } else if (elapsed > 6000) {
                        if (confirmTries < 3 && !findExact("目标按钮")) {
                            logStatus("未检测到确认弹窗，返回列表继续尝试");
                            performGlobalAction(GLOBAL_ACTION_BACK);
                            startHunt();
                        } else {
                            success();
                        }
                    }
                    if (awayMode && confirmTries > 6) {
                        exitAwayMode("确认弹窗未响应，已停止");
                    }
                    break;

                default:
                    break;
            }
        } catch (Exception e) {
            logStatus("异常：" + e);
        }

        handler.postDelayed(tick, TICK);
    }

    private void startHunt() {
        huntStart = now();
        lastRefresh = now();
        lastScrollAt = now();
        setStep(Step.HUNT);
        logStatus("已进入死盯模式：每0.5秒扫一次【目标按钮】");
    }

    /** 随机延迟 3~5 秒后进入 next 状态 */
    private void beginDelay(Step next) {
        pendingStep = next;
        delayUntil = now() + 3000 + rnd.nextInt(2001);
        setStep(Step.DELAY);
    }

    // ======================= 节点查找与点击 =======================

    /** 找到文本并点击（contains 模式，用于导航入口） */
    private boolean clickByText(String text, boolean exact) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        List<AccessibilityNodeInfo> list;
        try {
            list = root.findAccessibilityNodeInfosByText(text);
        } catch (Exception e) {
            return false;
        }
        if (list == null) return false;
        for (AccessibilityNodeInfo n : list) {
            CharSequence cs = n.getText();
            if (cs == null) continue;
            String s = cs.toString().trim();
            boolean hit = exact ? s.equals(text) : s.contains(text);
            if (!hit) continue;
            if (s.contains("详情")) continue;      // 防误触：绝不点详情
            if (doClick(n)) return true;
        }
        return false;
    }

    private boolean findExact(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text);
        if (list == null) return false;
        for (AccessibilityNodeInfo n : list) {
            CharSequence cs = n.getText();
            if (cs != null && cs.toString().trim().equals(text)) return true;
        }
        return false;
    }

    /** 只点文本精确为"目标按钮"的可点击按钮；"详情"永远跳过 */
    private boolean clickExactBaoming() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText("目标按钮");
        if (list == null) return false;
        for (AccessibilityNodeInfo n : list) {
            CharSequence cs = n.getText();
            if (cs == null) continue;
            String s = cs.toString().trim();
            // 必须完全等于"目标按钮"，"入口C""目标按钮中"等入口/状态不点
            if (!s.equals("目标按钮")) continue;
            if (doClick(n)) return true;
        }
        return false;
    }

    private boolean clickAnyExact(String[] texts) {
        for (String t : texts) {
            if (clickByText(t, true)) return true;
        }
        return false;
    }

    /** 点击节点：先 ACTION_CLICK，失败则坐标点击 */
    private boolean doClick(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur = node;
        int depth = 0;
        while (cur != null && depth < 10) {
            if (cur.isClickable() && cur.isEnabled()) {
                if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                Rect r = new Rect();
                cur.getBoundsInScreen(r);
                if (r.width() > 0 && r.height() > 0) return tap(r.centerX(), r.centerY());
            }
            AccessibilityNodeInfo p = cur.getParent();
            if (p == null) break;
            cur = p;
            depth++;
        }
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.width() <= 0 || r.height() <= 0) return false;
        return tap(r.centerX(), r.centerY());
    }

    private boolean tap(int x, int y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, 45));
        return dispatchGesture(b.build(), null, null);
    }

    private boolean swipeRefresh() {
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        float x = w / 2f;
        float fromY = h * SAFE_TOP_RATIO;
        float toY = h * (SAFE_TOP_RATIO + 0.32f);   // 只拖 32% 屏高，避免过度回弹
        if (toY > h * SAFE_BOTTOM_RATIO) toY = h * SAFE_BOTTOM_RATIO;
        return swipe(x, fromY, x, toY, 380);
    }

    private boolean swipeUpHalf() {
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        float x = w / 2f;
        float fromY = h * 0.66f;
        float toY = h * (SAFE_TOP_RATIO + 0.06f);
        return swipe(x, fromY, x, toY, 420);
    }

    /** 统一的手势出口，带回调日志，确认手势到底执行没有 */
    private boolean swipe(float x1, float y1, float x2, float y2, int durationMs) {
        try {
            Path p = new Path();
            p.moveTo(x1, y1);
            p.lineTo(x2, y2);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(new GestureDescription.StrokeDescription(p, 0, durationMs));
            boolean accepted = dispatchGesture(b.build(), new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    android.util.Log.i("GrabService", "手势完成");
                    lastGestureResult = "手势OK";
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    android.util.Log.i("GrabService", "手势被取消");
                    lastGestureResult = "手势取消";
                }
            }, null);
            lastGestureResult = accepted ? "手势提交" : "手势被拒";
            logStatus("滑动：" + lastGestureResult);
            return accepted;
        } catch (Exception e) {
            logStatus("滑动异常：" + e.getMessage());
            return false;
        }
    }

    /** 不依赖手势的滚动：对可滚动节点直接下指令 */
    private boolean scrollForwardByAction() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        return findScrollableAndScroll(root, 0);
    }

    private boolean findScrollableAndScroll(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 30) return false;
        try {
            CharSequence cn = node.getClassName();
            String clsName = cn == null ? "" : cn.toString();
            boolean webViewLike = clsName.contains("WebView") || clsName.contains("ScrollView")
                    || clsName.contains("RecyclerView") || clsName.contains("ListView");
            if (node.isScrollable() || webViewLike) {
                boolean ok = node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
                if (ok) {
                    logStatus("已用滚动指令翻页（手势不可用时的替代方案）");
                    return true;
                }
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                if (findScrollableAndScroll(node.getChild(i), depth + 1)) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    // ======================= 结果处理 =======================

    private void faultTolerance(String why) {
        faultCount++;
        // 先重新识别一次当前页：可能只是慢了一拍，其实已经在目标页
        Step nowPage = detectCurrentPage();
        if (nowPage == Step.HUNT) {
            logStatus("其实已在活动列表页，直接开始盯【目标按钮】");
            faultCount = 0;
            startHunt();
            return;
        }

        // 只在真的不在目标页时才返回，且每次故障只退一级
        logStatus(why + "，返回上一级重试（第" + faultCount + "次）");
        performGlobalAction(GLOBAL_ACTION_BACK);
        if (faultCount >= 4) {
            if (awayMode) {
                exitAwayMode("多次失败，已停止离开模式");
                return;
            }
            logStatus("连续失败，重新启动目标APP");
            launchTarget();
            faultCount = 0;
            setStep(Step.WAIT_TARGET);
        } else {
            // 退回一级后从首页识别开始重走流程
            setStep(Step.WAIT_TARGET);
        }
    }



    private void success() {
        if (step == Step.DONE) return;
        step = Step.DONE;
        handler.removeCallbacks(tick);
        vibrate();
        notifySuccess();
        writeRecord();
        logStatus("任务成功！已震动提示并记入记事本");
        // 成功即退出离开模式，恢复亮度
        if (awayMode) {
            handler.postDelayed(() -> exitAwayMode("已命中，已恢复亮度"), 800);
        }
        patrolActive = false;

    }

    private void stopNow(String reason) {
        step = Step.IDLE;
        handler.removeCallbacks(tick);
        logStatus(reason);
    }

    private void delayStep(Step next) {
        beginDelay(next);
    }

    private void setStep(Step s) {
        step = s;
        stepStart = now();
    }

    private long now() {
        return android.os.SystemClock.uptimeMillis();
    }

    /**
     * 首页「入口A」是一张图片，文字画在图里，无障碍读不到。
     * 兜底：按屏幕比例点击该卡片中心（依据实机截图：左侧卡片，约 54% 高度处）。
     */
    private boolean clickDachuanByCoord() {
        if (dachuanTried) return false;
        dachuanTried = true;
        logStatus("未读到【入口A】文字（图片卡片），改用坐标点击");
        // 首页左半边的"入口A"图片卡片，纵向约 37%
        return tapRatio(0.22f, 0.370f);
    }

    /** 按屏幕比例点击 */
    private boolean tapRatio(float rx, float ry) {
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        return tap((int) (w * rx), (int) (h * ry));
    }

    /** 入口A页：四列两行图标网格，入口B在第1行第1列 */
    private boolean clickXinyuByCoord() {
        logStatus("未读到【入口B】文字，改用坐标点击（网格第1格）");
        return tapRatio(0.125f, 0.435f);
    }

    /** 入口B页：四个卡片，入口C是第1个 */
    private boolean clickActivityTabByCoord() {
        logStatus("未读到【入口C】文字，改用坐标点击（第1张卡片）");
        return tapRatio(0.125f, 0.520f);
    }

    /** 滑动专项诊断：试手势、找可滚动节点，结果通过广播返回 */
    private void diagScroll() {
        StringBuilder sb = new StringBuilder();
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) {
                sb.append("读不到窗口（root=null）");
            } else {
                sb.append("包名：").append(root.getPackageName()).append("\n");
                // 1. 找可滚动节点
                int[] scrollable = {0};
                listScrollable(root, sb, scrollable, 0);
                sb.append("可滚动节点数：").append(scrollable[0]).append("\n");
                // 2. 尝试滚动指令
                boolean scrollOk = findScrollableAndScroll(root, 0);
                sb.append("滚动指令结果：").append(scrollOk ? "执行成功" : "未找到可滚动节点或执行失败").append("\n");
                // 3. 尝试手势
                boolean accepted = dispatchGesture(buildSwipe(0.5f, 0.66f, 0.5f, 0.22f, 420),
                        new GestureResultCallback() {
                            boolean done = false;
                            @Override public void onCompleted(GestureDescription g) {
                                android.util.Log.i("GrabService", "诊断手势完成");
                            }
                            @Override public void onCancelled(GestureDescription g) {
                                android.util.Log.i("GrabService", "诊断手势被取消");
                            }
                        }, null);
                sb.append("手势提交：").append(accepted ? "系统已接受" : "系统拒绝");
            }
        } catch (Exception e) {
            sb.append("异常：").append(e);
        }
        sendBroadcast(new Intent("com.example.autoclicker.SCROLL_DIAG").setPackage(getPackageName())
                .putExtra("msg", sb.toString()));
    }

    private GestureDescription buildSwipe(float x1r, float y1r, float x2r, float y2r, int dur) {
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        Path p = new Path();
        p.moveTo(w * x1r, h * y1r);
        p.lineTo(w * x2r, h * y2r);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, dur));
        return b.build();
    }

    private void listScrollable(AccessibilityNodeInfo node, StringBuilder sb, int[] count, int depth) {
        if (node == null || depth > 30 || count[0] > 5) return;
        try {
            if (node.isScrollable()) {
                count[0]++;
                CharSequence cls = node.getClassName();
                sb.append("· 可滚动节点 <").append(cls == null ? "?" : cls.toString()
                        .substring(cls.toString().lastIndexOf('.') + 1)).append(">\n");
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                listScrollable(node.getChild(i), sb, count, depth + 1);
            }
        } catch (Exception ignored) {
        }
    }

    /** 把当前屏幕能读到的所有文字收集起来（用于排查为什么点不到） */
    private void dumpScreen() {
        StringBuilder sb = new StringBuilder();
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) {
                sb.append("读不到任何窗口内容（root = null）");
            } else {
                sb.append("包名：").append(root.getPackageName()).append("\n");
                sb.append("子节点数：").append(root.getChildCount()).append("\n\n可读文字：\n");
                collectText(root, sb, 0);
                if (sb.toString().endsWith("可读文字：\n")) {
                    sb.append("（没有任何文字节点！说明页面内容对无障碍不可见）");
                }
            }
        } catch (Exception e) {
            sb.append("读取异常：").append(e);
        }
        sendBroadcast(new Intent("com.example.autoclicker.DUMP").setPackage(getPackageName())
                .putExtra("dump", sb.toString()));
        android.util.Log.i("GrabService", sb.toString());
    }

    private void collectText(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null || depth > 25) return;
        try {
            CharSequence t = node.getText();
            CharSequence d = node.getContentDescription();
            String label = (t != null ? t.toString().trim() : "");
            if (label.isEmpty() && d != null) label = d.toString().trim();
            if (!label.isEmpty()) {
                sb.append("· ").append(label);
                if (node.isClickable()) sb.append("  [可点击]");
                if (node.getClassName() != null) {
                    String cls = node.getClassName().toString();
                    int i = cls.lastIndexOf('.');
                    sb.append("  <").append(i >= 0 ? cls.substring(i + 1) : cls).append(">");
                }
                sb.append("\n");
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                collectText(node.getChild(i), sb, depth + 1);
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * 判断当前停在哪一页，返回该从哪个状态开始：
     *  · 列表页（有"目标按钮"或"详情"按钮 / 有"入口C"标题+卡片）→ HUNT
     *  · 入口B页（有"入口C/活动签到/上传成果/我的学时"四宫格）→ FIND_ACTIVITY_TAB
     *  · 首页（有"入口A"）→ FIND_DACHUAN
     */
    private Step detectCurrentPage() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return Step.FIND_DACHUAN;

        boolean hasDetail = hasTextExact(root, "详情");
        boolean hasBaomingBtn = hasTextExact(root, "目标按钮");
        boolean hasActivityTab = hasTextContains(root, "活动签到") || hasTextContains(root, "上传成果")
                || hasTextContains(root, "我的学时");
        boolean hasDachuan = hasTextContains(root, "入口A");

        // 列表页：出现"详情"按钮，或出现独立的"目标按钮"按钮
        if (hasDetail || hasBaomingBtn) return Step.HUNT;
        // 入口B页：四宫格里有其他模块（但不能是首页）
        if (hasActivityTab && !hasDachuan) return Step.FIND_ACTIVITY_TAB;
        // 入口B页（只看到"入口B"标题）
        if (hasTextContains(root, "入口B") && !hasDachuan) return Step.FIND_ACTIVITY_TAB;

        return Step.FIND_DACHUAN;
    }

    private boolean hasTextExact(AccessibilityNodeInfo root, String text) {
        try {
            List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text);
            if (list == null) return false;
            for (AccessibilityNodeInfo n : list) {
                if (n.getText() != null && n.getText().toString().trim().equals(text)) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean hasTextContains(AccessibilityNodeInfo root, String text) {
        try {
            List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text);
            return list != null && !list.isEmpty();
        } catch (Exception ignored) {
        }
        return false;
    }

    /** 页面是否已渲染出可读内容（有子节点即认为就绪） */
    private boolean pageReady() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        if (!TARGET_PKG.equals(root.getPackageName())) return false;
        return root.getChildCount() > 0;
    }

    private boolean isTargetForeground() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && TARGET_PKG.equals(root.getPackageName())) return true;
            for (AccessibilityWindowInfo w : getWindows()) {
                AccessibilityNodeInfo r = w.getRoot();
                if (r != null && TARGET_PKG.equals(r.getPackageName())) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void launchTarget() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(TARGET_PKG);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        } catch (Exception ignored) {
        }
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            long[] pattern = {0, 500, 150, 500, 150, 900};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            } else {
                v.vibrate(pattern, -1);
            }
        } catch (Exception ignored) {
        }
    }

    // ======================= 通知 =======================

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;

        NotificationChannel ch = new NotificationChannel("grab_success", "任务成功提醒", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("命中活动后立即横幅提醒");
        ch.enableLights(true);
        ch.setLightColor(0xFFFF0000);
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 500, 150, 500, 150, 900});
        ch.setBypassDnd(true);            // 免打扰也响
        ch.setShowBadge(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ch.setSound(Settings.System.DEFAULT_NOTIFICATION_URI,
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
        nm.createNotificationChannel(ch);

        // 状态通知：新渠道 ID（旧渠道在用户机上已固化为 MIN，无法更新）
        NotificationChannel st = new NotificationChannel("grab_status_v2", "运行状态", NotificationManager.IMPORTANCE_LOW);
        st.setDescription("显示自动目标按钮助手的运行状态");
        st.setShowBadge(false);
        st.setSound(null, null);
        st.enableVibration(false);
        st.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(st);
    }

    private void notifySuccess() {
        Notification.Builder b;
        String time = new SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(new Date());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            b = new Notification.Builder(this, "grab_success");
        } else {
            b = new Notification.Builder(this).setPriority(Notification.PRIORITY_MAX);
        }
        b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("命中了！任务成功")
                .setContentText("已目标按钮【" + grabbedName + "】" + time)
                .setStyle(new Notification.BigTextStyle()
                        .bigText("已成功目标按钮【" + grabbedName + "】\n时间：" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date())
                                + "\n请打开APP确认目标按钮详情。"))
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setDefaults(Notification.DEFAULT_ALL)
                .setOnlyAlertOnce(false);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.cancel(1001);
            nm.notify(1001, b.build());
        }
    }

    /** 更新运行状态（写入日志并广播给界面显示） */
    private void logStatus(String msg) {
        lastLog = msg;
        android.util.Log.i("GrabService", msg);
        try {
            sendBroadcast(new Intent("com.example.autoclicker.STATUS").setPackage(getPackageName())
                    .putExtra("msg", msg));
        } catch (Exception ignored) {
        }
        // 离开模式下把进度同步到常驻通知（节流，避免高频 notify 拖慢系统）
        if (awayMode) {
            long t = now();
            if (t - lastNotifyAt > 3000) {
                lastNotifyAt = t;
                updateStatusNotification(msg);
            }
        }
    }

    // ======================= 记事本 =======================

    private void writeRecord() {
        try {
            File f = new File(getFilesDir(), RECORD_FILE);
            String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
            String line = "【" + time + "】已目标按钮：" + grabbedName;
            OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(f, true), "UTF-8");
            w.write(line + "\n");
            w.close();
        } catch (Exception e) {
            android.util.Log.e("GrabService", "writeRecord", e);
        }
    }

    @SuppressWarnings("unused")
    private boolean installed() {
        try {
            getPackageManager().getPackageInfo(TARGET_PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
