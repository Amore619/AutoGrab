package com.example.autoclicker;

import android.app.Activity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** 内置使用说明页 */
public class HelpActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);

        addTitle(root, "AutoGrab · 使用说明");
        addBody(root,
                "本工具通过 Android 无障碍服务操作「目标APP」（com.example.targetapp），"
                        + "自动完成：入口A → 入口B → 入口C → 命中「目标按钮」按钮的全流程。");

        addTitle(root, "一、首次使用（3 步）");
        addBody(root,
                "1. 点击首页「开启无障碍服务」，在系统列表里找到【AutoGrab】，打开开关。\n"
                        + "   · 小米澎湃OS会提示「此应用非官方应用商店下载」和「存在风险」，选择「仍然允许/继续」。\n"
                        + "2. 回到本应用首页，点击「启动目标APP」\n"
                        + "   · 若已手动打开目标APP首页，也可直接切过去，服务会自动识别。\n"
                        + "3. 流程自动开始，首页底部会实时显示当前进行到哪一步。");

        addTitle(root, "二、小米 / 澎湃OS 必做设置（否则收不到提醒）");
        addBody(root,
                "① 通知权限（关键）\n"
                        + "   设置 → 通知与控制中心 → 通知管理 → 找到本应用\n"
                        + "   → 打开「允许通知」\n"
                        + "   → 打开「横幅通知」或「悬浮通知」\n"
                        + "   → 通知类别里的「任务成功提醒」也要单独打开横幅\n"
                        + "   → 重要性/级别调到「紧急」或「高」\n\n"
                        + "② 后台保活（防止流程被系统杀掉）\n"
                        + "   · 最近任务界面：下拉本应用卡片 → 点锁图标锁定\n"
                        + "   · 设置 → 应用设置 → 本应用 → 省电策略 → 选择「无限制」\n"
                        + "   · 设置 → 应用设置 → 本应用 → 自启动 → 允许\n\n"
                        + "③ 无障碍开关会被系统定时关闭\n"
                        + "   澎湃OS 有时会自动关闭第三方无障碍应用，任务前请回首页确认状态是否还是「已开启」。");

        addTitle(root, "三、静默巡逻（不知道放活动时间就用这个）");
        addBody(root,
                "学校什么时候放活动完全没规律？用静默巡逻，你什么都不用管。\n\n"
                        + "工作条件（两个同时满足才动手）：\n"
                        + "  ① 屏幕已熄灭     ② 手机正在充电\n\n"
                        + "每一轮做什么：\n"
                        + "  · 亮屏 → 打开目标APP → 入口A → 入口B → 入口C\n"
                        + "  · 扫一遍列表，有「目标按钮」命中，没有就关屏休眠\n"
                        + "  · 约 30 秒检查一次屏幕状态，息屏充电就再检查一遍\n\n"
                        + "为什么不会打扰你：\n"
                        + "  · 你在用手机（屏幕亮着）时，它一步都不动\n"
                        + "  · 巡逻进行到一半你解锁手机，它立刻退出并把屏幕让给你\n"
                        + "  · 每轮结束自动关屏，不会留一个亮着的屏幕等你\n"
                        + "  · 命中后自动停止巡逻，不会重复乱动");

        addTitle(root, "四、自动流程细节");
        addBody(root,
                "· 点击「入口A」后等待 3~5 秒随机延迟，等 H5 网页真正加载完\n"
                        + "· 点击「入口B」后再等 3~5 秒\n"
                        + "· 进入活动列表后每 0.5 秒扫描一次屏幕\n"
                        + "· 只点文字完全等于「目标按钮」的按钮\n"
                        + "· 任何包含「详情」的按钮一律跳过，绝不误点\n"
                        + "· 没发现「目标按钮」：每 10 秒下拉刷新一次；每 15 秒向上滑半屏，看下面的活动卡片\n"
                        + "· 发现「目标按钮」：立即点击，并自动处理「确定 / 确认 / 提交 / 立即目标按钮 / 我已知晓」弹窗\n"
                        + "· 命中后：震动三段 + 最高优先级横幅通知 + 自动写入记事本，然后自动停止\n"
                        + "· 容错：某步 30 秒没找到按钮，会自动按返回键退回重试；连续失败 4 次自动重启APP\n"
                        + "· 蹲守上限 30 分钟，超时自动停止，避免整夜空转耗电");

        addTitle(root, "五、常见问题");
        addBody(root,
                "Q：点「开启无障碍服务」后列表里找不到本应用？\n"
                        + "A：先手动打开一次本应用再试；或在设置→无障碍→已下载的服务里查找。\n\n"
                        + "Q：流程卡在「未找到入口B」？\n"
                        + "A：多为网页未加载完或网络慢。服务会自动返回重试；也可以把延迟调大。\n\n"
                        + "Q：命中但没收到横幅通知？\n"
                        + "A：99% 是小米的通知权限没开「横幅/悬浮」。按上面第二部分设置，然后随便发一条测试通知验证。\n\n"
                        + "Q：能同时命中多个活动吗？\n"
                        + "A：当前版本点中第一个「目标按钮」就停止。如需继续，重新点「启动流程」即可。\n\n"
                        + "Q：会不会误点「详情」浪费机会？\n"
                        + "A：不会。代码在点击前会校验节点文本必须完全等于「目标按钮」，含「详情」的节点被显式排除。");

        addTitle(root, "六、免责声明");
        addBody(root,
                "本工具为个人学习 Android 无障碍服务（AccessibilityService）而编写的自动化示例。"
                        + "使用自动化手段任务可能违反学校平台的用户协议，请自行评估风险，"
                        + "因使用本工具产生的一切后果由使用者自行承担。建议仅用于技术学习。");

        sv.addView(root);
        setContentView(sv);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void addTitle(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(17);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setGravity(Gravity.START);
        tv.setPadding(0, dp(18), 0, dp(8));
        parent.addView(tv);
    }

    private void addBody(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setLineSpacing(dp(4), 1f);
        parent.addView(tv);
    }
}
