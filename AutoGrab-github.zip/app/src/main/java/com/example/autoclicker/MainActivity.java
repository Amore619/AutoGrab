package com.example.autoclicker;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView statusView;
    private TextView accessView;
    private TextView diagView;
    private android.content.SharedPreferences prefs;
    private int batteryMin = 30;
    private int awayBrightness = 45;

    private final BroadcastReceiver dumpReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String dump = intent.getStringExtra("dump");
            if (dump == null) return;
            android.widget.ScrollView sv = new android.widget.ScrollView(MainActivity.this);
            TextView tv = new TextView(MainActivity.this);
            tv.setText(dump);
            tv.setTextSize(12);
            tv.setPadding(dp(16), dp(16), dp(16), dp(16));
            tv.setTextIsSelectable(true);
            sv.addView(tv);
            new android.app.AlertDialog.Builder(MainActivity.this)
                    .setTitle("当前屏幕可读到的文字")
                    .setView(sv)
                    .setPositiveButton("关闭", null)
                    .show();
        }
    };

    private final BroadcastReceiver diagReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra("msg");
            if (msg != null && diagView != null) diagView.setText("自检：" + msg);
        }
    };

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra("msg");
            if (msg != null) statusView.setText("状态：" + msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        int pad = dp(18);
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("AutoGrab");
        title.setTextSize(21);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("目标应用：目标APP (com.example.targetapp)");
        sub.setTextSize(12);
        sub.setPadding(0, dp(4), 0, dp(12));
        root.addView(sub);

        accessView = new TextView(this);
        accessView.setTextSize(14);
        accessView.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(accessView, lp());

        statusView = new TextView(this);
        statusView.setText("状态：等待启动");
        statusView.setTextSize(14);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(statusView, lp());

        diagView = new TextView(this);
        diagView.setText("自检：未开启巡逻");
        diagView.setTextSize(12);
        diagView.setTextColor(Color.parseColor("#333333"));
        diagView.setLineSpacing(dp(3), 1f);
        diagView.setPadding(dp(12), dp(6), dp(12), dp(6));
        root.addView(diagView, lp());

        Button btnAcc = new Button(this);
        btnAcc.setText("1. 开启无障碍服务");
        btnAcc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(btnAcc, lp());

        Button btnApp = new Button(this);
        btnApp.setText("2. 启动目标APP 并 开始自动目标按钮");
        btnApp.setOnClickListener(v -> {
            if (!isAccessibilityOn()) {
                Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                return;
            }
            Intent i = getPackageManager().getLaunchIntentForPackage("com.example.targetapp");
            if (i == null) {
                Toast.makeText(this, "未安装目标APP(com.example.targetapp)", Toast.LENGTH_LONG).show();
                return;
            }
            startActivity(i);
            // 拉起目标APP同时启动服务
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                startService(new Intent(this, GrabService.class));
                Toast.makeText(this, "自动流程已启动", Toast.LENGTH_SHORT).show();
            }, 1200);
        });
        root.addView(btnApp, lp());

        Button btnNotify = new Button(this);
        btnNotify.setText("3. 打开本应用通知设置（务必开横幅）");
        btnNotify.setOnClickListener(v -> openNotificationSettings());
        root.addView(btnNotify, lp());

        Button btnTest = new Button(this);
        btnTest.setText("4. 发送测试通知（验证横幅是否正常）");
        btnTest.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 100);
                return;
            }
            sendTestNotification();
        });
        root.addView(btnTest, lp());

        Button btnStop = new Button(this);
        btnStop.setText("停止自动流程");
        btnStop.setOnClickListener(v -> {
            Intent i = new Intent(this, GrabService.class);
            i.setAction(GrabService.ACTION_STOP);
            startService(i);
            statusView.setText("状态：已发送停止指令");
        });
        root.addView(btnStop, lp());

        // ---------- 离开模式 ----------
        TextView patrolTitle = new TextView(this);
        patrolTitle.setText("—— 离开模式 ——");
        patrolTitle.setTextSize(15);
        patrolTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        patrolTitle.setPadding(0, dp(16), 0, dp(4));
        root.addView(patrolTitle);

        TextView patrolDesc = new TextView(this);
        patrolDesc.setText("离开座位前点一下：屏幕自动调暗到45% → 5秒后切到目标APP → 自动盯活动列表找目标按钮。"
                + "回来点一下「我回来了」，亮度恢复、自动停止。"
                + "通知栏会常驻一条状态，随时能确认它还活着。");
        patrolDesc.setTextSize(12);
        root.addView(patrolDesc);

        // 亮度滑块
        final TextView brightLabel = new TextView(this);
        brightLabel.setText("离开时屏幕亮度：45%（远处不易看清内容）");
        brightLabel.setTextSize(13);
        brightLabel.setPadding(0, dp(10), 0, 0);
        root.addView(brightLabel);

        android.widget.SeekBar bseek = new android.widget.SeekBar(this);
        bseek.setMax(70);
        bseek.setProgress(37);   // ≈45%
        bseek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int value, boolean fromUser) {
                awayBrightness = Math.max(26, Math.min(value + 8, 80));
                brightLabel.setText("离开时屏幕亮度：" + awayBrightness + "%");
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) { }
        });
        root.addView(bseek);

        // 电量阈值
        final TextView batLabel = new TextView(this);
        batLabel.setText("电量低于 " + batteryMin + "% 时自动停止");
        batLabel.setTextSize(13);
        batLabel.setPadding(0, dp(10), 0, 0);
        root.addView(batLabel);

        android.widget.SeekBar seek = new android.widget.SeekBar(this);
        seek.setMax(70);
        seek.setProgress(batteryMin - 10);
        seek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int value, boolean fromUser) {
                batteryMin = Math.max(10, Math.min(value + 10, 80));
                batLabel.setText("电量低于 " + batteryMin + "% 时自动停止");
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) { }
        });
        root.addView(seek);

        Button btnAway = new Button(this);
        btnAway.setText("我离开了（调暗屏幕并开始盯）");
        btnAway.setOnClickListener(v -> {
            if (!isAccessibilityOn()) {
                Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                return;
            }
            if (!Settings.System.canWrite(this)) {
                new android.app.AlertDialog.Builder(this)
                        .setTitle("需要「修改系统设置」权限")
                        .setMessage("调暗屏幕必须要这个权限，否则亮度不会变。\n\n"
                                + "点「去授权」后会跳到系统设置页，找到本应用并打开开关，然后返回本页面重新点「我离开了」。\n\n"
                                + "这个权限只用于调整屏幕亮度，不会读取或修改你的其他设置。")
                        .setPositiveButton("去授权", (d, w) -> {
                            try {
                                Intent i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                                        Uri.parse("package:" + getPackageName()));
                                startActivity(i);
                            } catch (Exception e) {
                                startActivity(new Intent(Settings.ACTION_SETTINGS));
                            }
                        })
                        .setNegativeButton("先不授权，只执行不调暗", (d, w) -> startAwayMode())
                        .show();
                return;
            }
            startAwayMode();
        });
        root.addView(btnAway, lp());

        Button btnBack = new Button(this);
        btnBack.setText("我回来了（恢复亮度并停止）");
        btnBack.setOnClickListener(v -> {
            // 主界面直接恢复亮度
            try {
                int old = prefs.getInt("old_brightness", -1);
                if (old > 0 && Settings.System.canWrite(this)) {
                    Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, old);
                }
            } catch (Exception ignored) {
            }
            Intent i = new Intent(this, GrabService.class);
            i.setAction(GrabService.ACTION_BACK);
            startService(i);
            statusView.setText("状态：已停止，亮度已恢复");
        });
        root.addView(btnBack, lp());

        Button btnDump = new Button(this);
        btnDump.setText("读取当前屏幕文字（排查为什么点不到）");
        btnDump.setOnClickListener(v -> {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("怎么用")
                    .setMessage("先切到目标APP的页面，然后再切回本应用点这个按钮？\n\n"
                            + "不行——切回来就读不到它了。\n\n"
                            + "正确做法：让本应用先在后台，用最近任务切到目标APP，"
                            + "再点下面「延时8秒读取」，8秒内切到目标APP保持不动。")
                    .setPositiveButton("延时8秒读取", (d, w) -> {
                        Toast.makeText(this, "8秒内切到目标APP，不要动屏幕", Toast.LENGTH_LONG).show();
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            Intent i = new Intent(this, GrabService.class);
                            i.setAction(GrabService.ACTION_DUMP);
                            startService(i);
                        }, 8000);
                    })
                    .setNegativeButton("取消", null)
                    .show();
        });
        root.addView(btnDump, lp());

        Button btnDiag = new Button(this);
        btnDiag.setText("立即自检（会弹窗显示结果）");
        btnDiag.setOnClickListener(v -> {
            Toast.makeText(this, "正在检测…", Toast.LENGTH_SHORT).show();
            try {
                runSelfCheck();
            } catch (Exception e) {
                new android.app.AlertDialog.Builder(this)
                        .setTitle("自检出错")
                        .setMessage(String.valueOf(e))
                        .setPositiveButton("知道了", null)
                        .show();
            }
        });
        root.addView(btnDiag, lp());

        Button btnRec = new Button(this);
        btnRec.setText("查看命中的活动（记事本）");
        btnRec.setOnClickListener(v -> startActivity(new Intent(this, RecordsActivity.class)));
        root.addView(btnRec, lp());

        Button btnHelp = new Button(this);
        btnHelp.setText("使用说明");
        btnHelp.setOnClickListener(v -> startActivity(new Intent(this, HelpActivity.class)));
        root.addView(btnHelp, lp());

        TextView warn = new TextView(this);
        warn.setText("提示：小米澎湃OS需在通知管理里单独打开「横幅通知」，并锁定后台、省电策略设为「无限制」，否则提醒会被拦截。");
        warn.setTextSize(12);
        warn.setTextColor(Color.parseColor("#B23B3B"));
        warn.setPadding(0, dp(16), 0, dp(8));
        root.addView(warn);

        sv.addView(root);
        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 100);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAccessState();
        IntentFilter f = new IntentFilter("com.example.autoclicker.STATUS");
        IntentFilter f2 = new IntentFilter("com.example.autoclicker.DIAG");
        IntentFilter f3 = new IntentFilter("com.example.autoclicker.DUMP");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, f, Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(diagReceiver, f2, Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(dumpReceiver, f3, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(statusReceiver, f);
            registerReceiver(diagReceiver, f2);
            registerReceiver(dumpReceiver, f3);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { unregisterReceiver(statusReceiver); } catch (Exception ignored) { }
        try { unregisterReceiver(diagReceiver); } catch (Exception ignored) { }
        try { unregisterReceiver(dumpReceiver); } catch (Exception ignored) { }
    }

    private void refreshAccessState() {
        boolean on = isAccessibilityOn();
        accessView.setText(on ? "无障碍服务：已开启 ✓" : "无障碍服务：未开启 ✗  请点击下方第1步开启");
        accessView.setBackgroundColor(Color.parseColor(on ? "#E3F5E5" : "#FCE7E7"));
        accessView.setTextColor(Color.parseColor(on ? "#1B6B2A" : "#A32020"));
    }

    private boolean isAccessibilityOn() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        ComponentName me = new ComponentName(this, GrabService.class);
        String flat = me.flattenToString();
        String shortName = me.flattenToShortString();
        return enabled.contains(flat) || enabled.contains(shortName);
    }

    private void openNotificationSettings() {
        Intent i = new Intent();
        if (Build.VERSION.SDK_INT >= 26) {
            i.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
        }
        try {
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void sendTestNotification() {
        android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
        if (nm == null) return;
        android.app.Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new android.app.Notification.Builder(this, "grab_success");
        } else {
            b = new android.app.Notification.Builder(this).setPriority(android.app.Notification.PRIORITY_MAX);
        }
        b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("这是一条测试通知")
                .setContentText("如果你看到横幅弹出，说明通知权限配置正确。")
                .setAutoCancel(true)
                .setDefaults(android.app.Notification.DEFAULT_ALL)
                .setPriority(android.app.Notification.PRIORITY_MAX);
        nm.notify(2002, b.build());
        Toast.makeText(this, "已发送测试通知", Toast.LENGTH_SHORT).show();
    }

    /** 本地自检：直接读取系统状态，不依赖无障碍服务是否存活 */
    private void runSelfCheck() {
        StringBuilder sb = new StringBuilder();
        boolean acc = false;
        try {
            acc = isAccessibilityOn();
            sb.append(acc ? "✓ 无障碍：已开启" : "✗ 无障碍：未开启（服务无法工作）");
        } catch (Exception e) {
            sb.append("? 无障碍：检测失败 ").append(e.getMessage());
        }

        try {
            boolean canWrite = Settings.System.canWrite(this);
            sb.append("\n").append(canWrite ? "✓ 修改系统设置：已授权（可调亮度）"
                    : "✗ 修改系统设置：未授权（亮度不会变）");
        } catch (Exception e) {
            sb.append("\n? 修改系统设置：检测失败");
        }

        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
            boolean screenOn = pm != null && pm.isInteractive();
            sb.append("\n").append(screenOn ? "· 屏幕：亮着" : "· 屏幕：已熄灭");
        } catch (Exception ignored) {
        }

        try {
            Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int lv = b.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                int sc = b.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
                sb.append("\n· 电量：").append(sc > 0 ? (lv * 100 / sc) + "%" : "未知");
            }
        } catch (Exception ignored) {
        }

        try {
            android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
            boolean enabled = nm != null && nm.areNotificationsEnabled();
            sb.append("\n").append(enabled ? "✓ 通知权限：已允许" : "✗ 通知权限：已关闭（收不到提醒）");
        } catch (Exception ignored) {
        }

        boolean target = false;
        try {
            getPackageManager().getPackageInfo("com.example.targetapp", 0);
            target = true;
        } catch (Exception ignored) {
        }
        sb.append("\n").append(target ? "✓ 目标APP：已安装" : "✗ 目标APP：未安装");

        diagView.setText("自检结果：\n" + sb);

        // 弹窗显示，确保一定能看到（不再依赖是否需要滚动）
        new android.app.AlertDialog.Builder(this)
                .setTitle("自检结果")
                .setMessage(sb.toString())
                .setPositiveButton("知道了", null)
                .show();
    }

    private void startAwayMode() {
        // 主线程直接调暗，立刻生效，不依赖服务是否活着
        boolean dimmed = false;
        if (Settings.System.canWrite(this)) {
            try {
                int old = Settings.System.getInt(getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS, 128);
                prefs.edit().putInt("old_brightness", old).apply();
                Settings.System.putInt(getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                int target = awayBrightness * 255 / 100;
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, target);
                dimmed = true;
            } catch (Exception e) {
                Toast.makeText(this, "调亮度失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        Intent i2 = new Intent(this, GrabService.class);
        i2.setAction(GrabService.ACTION_AWAY);
        i2.putExtra(GrabService.EXTRA_BATTERY_MIN, batteryMin);
        i2.putExtra(GrabService.EXTRA_BRIGHTNESS, awayBrightness * 255 / 100);
        i2.putExtra("already_dimmed", dimmed);
        startService(i2);

        statusView.setText(dimmed
                ? "状态：已调暗至 " + awayBrightness + "%，5秒后切到目标APP"
                : "状态：未授权调亮度，5秒后切到目标APP");
        Toast.makeText(this, dimmed ? "已调暗屏幕，5秒后跳转" : "已开启（亮度未调整）",
                Toast.LENGTH_LONG).show();
    }

    /** 申请设备管理器权限（仅用于巡逻结束后自动关屏） */
    private void askDeviceAdmin() {
        try {
            android.app.admin.DevicePolicyManager dpm =
                    (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            ComponentName cn = new ComponentName(this, SleepAdmin.class);
            if (dpm != null && !dpm.isAdminActive(cn)) {
                Intent i = new Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                i.putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn);
                i.putExtra(android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "仅用于巡逻结束后自动关闭屏幕，避免屏幕常亮。不会影响你的任何数据。");
                startActivity(i);
            }
        } catch (Exception ignored) {
        }
    }

    private LinearLayout.LayoutParams lp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(6);
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
